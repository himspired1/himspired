export const colors = {
  primary_color: "#68191E",
  black: "#000000",
  light_text: "#FFF3E3",
};
